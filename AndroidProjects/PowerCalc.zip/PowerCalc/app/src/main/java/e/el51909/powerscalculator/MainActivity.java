package e.el51909.powerscalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    private EditText value;
    private EditText powers;
    private TextView outPut;
    private Float nValue;
    private Float pValue;
    private Float answer;

    public void buttonOnClick(View v){

        value = (EditText) findViewById(R.id.txtValue);
        powers = (EditText) findViewById(R.id.txtPower);
        outPut = (TextView) findViewById(R.id.outPut);

        nValue = Float.parseFloat(value.getText().toString());
        pValue = Float.parseFloat(powers.getText().toString());
        float num = 1;

        for(int i = 0; i < pValue; i++){

           num = num*nValue;
        }

        answer = num;
        outPut.setText(String.valueOf(answer));
    }
}
