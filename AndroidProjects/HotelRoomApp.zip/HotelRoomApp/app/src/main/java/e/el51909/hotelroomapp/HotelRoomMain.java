package e.el51909.hotelroomapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HotelRoomMain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_room_main);
        Button b = (Button) findViewById(R.id.hotelDetails);

        //set onclick listener
        b.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                startActivity((new Intent(HotelRoomMain.this, HotelDetails.class)));
            }
        });
    }
}
