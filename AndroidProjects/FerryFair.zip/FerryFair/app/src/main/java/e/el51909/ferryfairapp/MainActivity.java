package e.el51909.ferryfairapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {

    double ticketPrice = 18;
    int numTickets;
    double totalCost;
    String location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText tickets = (EditText) findViewById(R.id.txtQty);

        final Spinner local = (Spinner) findViewById(R.id.txtLocation);

        Button calc = (Button) findViewById(R.id.btnCalc);
        calc.setOnClickListener(new View.OnClickListener() {

            final TextView outPut = (TextView) findViewById(R.id.txtOutPut);

            public void onClick(View view) {
               numTickets = Integer.parseInt(tickets.getText().toString());
               totalCost = ticketPrice * numTickets;
               location = local.getSelectedItem().toString();

                NumberFormat curency = NumberFormat.getCurrencyInstance();
                String totCos = curency.format(totalCost);

                outPut.setText(numTickets + " tickets to " + location + " is " + totCos);
            }
        });
    }
}

