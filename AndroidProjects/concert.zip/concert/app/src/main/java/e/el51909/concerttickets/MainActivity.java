package e.el51909.concerttickets;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    //declare global variables
    double costPerTicket = 79.99;
    int numTickets;
    double totalCost;
    String groupChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //acquire number of tickets
        final EditText tickets = (EditText) findViewById(R.id.txtTickets);

        //acquire concert selected
        final Spinner group = (Spinner) findViewById(R.id.txtGroup);

        //initialize the button
        Button cost = (Button) findViewById(R.id.txtCost);
        cost.setOnClickListener(new View.OnClickListener(){
            final TextView result = (TextView) findViewById(R.id.txtOutput);

            public void onClick(View v){
                numTickets = Integer.parseInt(tickets.getText().toString());
                totalCost = costPerTicket * numTickets;
                groupChoice = group.getSelectedItem().toString();
                DecimalFormat currency = new DecimalFormat("$###,###.##");

                result.setText("The total cost for " + groupChoice + " is " + currency.format(totalCost));
            }
        });
    }
}
