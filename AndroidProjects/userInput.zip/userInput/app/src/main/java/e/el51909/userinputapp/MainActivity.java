package e.el51909.userinputapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    private EditText favColor;
    private TextView textOut;
    private Float bTotal;

    public void buttonOnClick(View v){
       //do something when button is clicked
        Button button = (Button) v;
        ((Button) v).setText("Pressed");
        //startActivity(new Intent(getApplicationContext(), Main2Activity.class));

        favColor = (EditText) findViewById(R.id.txtTotal);
        textOut = (TextView) findViewById(R.id.favLbl);

        bTotal = Float.parseFloat(favColor.getText().toString());

        bTotal = (bTotal * 0.06f) + bTotal;



        textOut.setText(String.valueOf(bTotal));
    }
}
